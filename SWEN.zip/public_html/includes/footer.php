
<footer class="footer mt-auto py-3 bg-light">
    <div class="container text-center">
        <span class="text-muted">&copy; 2024 SWEN.Regestired for E-business project work. Created by <strong>Phurba Sherpa </strong> <b>221ADM061</b></span>
    </div>
</footer>
